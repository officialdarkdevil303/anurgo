// ==============================================================================
// ANURGO STUDIO — DATABASE INITIALIZER (Using Node.js native SQLite)
// ==============================================================================
// Runs on Node 22+ with zero native compile dependencies!
// ==============================================================================

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { DatabaseSync } from 'node:sqlite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = path.join(__dirname, 'anurgo.db');
const schemaPath = path.join(__dirname, 'schema.sql');
const seedPath = path.join(__dirname, 'seed.sql');

console.log('🔄 Initializing ANURGO SQLite Database at:', dbPath);

const db = new DatabaseSync(dbPath);

try {
  // Read and execute schema
  const schemaSql = fs.readFileSync(schemaPath, 'utf8');
  db.exec(schemaSql);
  console.log('✅ Schema tables created successfully.');

  // Check if leads table is empty
  const countRow = db.prepare('SELECT COUNT(*) as count FROM leads').get();
  if (countRow && countRow.count === 0) {
    if (fs.existsSync(seedPath)) {
      const seedSql = fs.readFileSync(seedPath, 'utf8');
      db.exec(seedSql);
      console.log('🌱 Seed data populated successfully.');
    }
  } else {
    console.log(`ℹ️ Database already contains ${countRow.count} leads. Skipping seed.`);
  }

  console.log('🎉 ANURGO Database ready to use!');
} catch (err) {
  console.error('❌ Database initialization error:', err);
  process.exit(1);
} finally {
  db.close();
}
