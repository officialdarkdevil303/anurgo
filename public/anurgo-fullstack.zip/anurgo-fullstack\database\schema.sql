-- ==============================================================================
-- ANURGO STUDIO — DATABASE SCHEMA (SQLite / PostgreSQL Compatible)
-- ==============================================================================

-- 1. Leads Table: Project Briefs and Inquiries
CREATE TABLE IF NOT EXISTS leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  business_name TEXT,
  phone TEXT,
  project_type TEXT NOT NULL DEFAULT 'website',
  budget TEXT NOT NULL DEFAULT 'undisclosed',
  timeline TEXT NOT NULL DEFAULT 'flexible',
  details TEXT,
  status TEXT NOT NULL DEFAULT 'new' CHECK(status IN ('new', 'contacted', 'in_discussion', 'proposal_sent', 'booked', 'archived')),
  source TEXT DEFAULT 'portfolio_brief_form',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. Feedback Table: Creator Feedback Submissions
CREATE TABLE IF NOT EXISTS feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
  category TEXT NOT NULL CHECK(category IN ('design', 'speed', 'pricing', 'copilot', 'other')),
  message TEXT NOT NULL,
  user_name TEXT,
  user_role TEXT,
  is_approved_testimonial INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 3. Chat Sessions Table: ANURGO AI Chatbot Conversations
CREATE TABLE IF NOT EXISTS chat_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT UNIQUE NOT NULL,
  title TEXT,
  language TEXT DEFAULT 'en',
  business_type TEXT,
  detected_budget TEXT,
  message_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 4. Chat Messages Table: Turn-by-Turn Dialog History
CREATE TABLE IF NOT EXISTS chat_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT NOT NULL,
  sender TEXT NOT NULL CHECK(sender IN ('user', 'ai', 'system')),
  text TEXT NOT NULL,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (session_id) REFERENCES chat_sessions(session_id) ON DELETE CASCADE
);

-- 5. Site Analytics Table: Page Views and Visitor Counter
CREATE TABLE IF NOT EXISTS site_analytics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  page_path TEXT NOT NULL DEFAULT '/',
  referrer TEXT,
  user_agent TEXT,
  screen_resolution TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_leads_email ON leads(email);
CREATE INDEX IF NOT EXISTS idx_leads_created_at ON leads(created_at);
CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id);
