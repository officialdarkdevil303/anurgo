import { Router } from 'express';
import db from '../db/index.js';

const router = Router();

/**
 * POST /api/leads
 * Submit a new Project Brief from the contact section
 */
router.post('/', (req, res) => {
  try {
    const {
      fullName,
      email,
      businessName,
      phone,
      projectType,
      budget,
      timeline,
      details,
    } = req.body;

    if (!fullName || !email) {
      return res.status(400).json({
        success: false,
        error: 'Full name and email are required fields.',
      });
    }

    const leadId = `lead-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const stmt = db.prepare(`
      INSERT INTO leads (
        lead_id,
        full_name,
        email,
        business_name,
        phone,
        project_type,
        budget,
        timeline,
        details,
        status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'new')
    `);

    stmt.run(
      leadId,
      fullName.trim(),
      email.trim().toLowerCase(),
      businessName ? businessName.trim() : null,
      phone ? phone.trim() : null,
      projectType || 'website',
      budget || 'undisclosed',
      timeline || 'flexible',
      details ? details.trim() : ''
    );

    console.log(`📩 New Project Brief received: ${fullName} (${email}) for [${projectType || 'website'}]`);

    return res.status(201).json({
      success: true,
      message: 'Project brief submitted successfully! Anurag will reach out shortly.',
      leadId,
    });
  } catch (err) {
    console.error('Error inserting lead:', err);
    return res.status(500).json({
      success: false,
      error: 'Failed to save project brief to database.',
    });
  }
});

/**
 * GET /api/leads
 * Retrieve all project inquiries (sorted by newest first)
 */
router.get('/', (req, res) => {
  try {
    const stmt = db.prepare('SELECT * FROM leads ORDER BY id DESC');
    const leads = stmt.all();

    return res.json({
      success: true,
      count: leads.length,
      data: leads,
    });
  } catch (err) {
    console.error('Error fetching leads:', err);
    return res.status(500).json({
      success: false,
      error: 'Failed to fetch leads.',
    });
  }
});

/**
 * PATCH /api/leads/:leadId/status
 * Update lead workflow status (e.g. new -> in_discussion -> booked)
 */
router.patch('/:leadId/status', (req, res) => {
  try {
    const { leadId } = req.params;
    const { status } = req.body;

    const allowed = ['new', 'contacted', 'in_discussion', 'proposal_sent', 'booked', 'archived'];
    if (!allowed.includes(status)) {
      return res.status(400).json({
        success: false,
        error: `Invalid status. Allowed: ${allowed.join(', ')}`,
      });
    }

    const stmt = db.prepare(`
      UPDATE leads 
      SET status = ?, updated_at = CURRENT_TIMESTAMP 
      WHERE lead_id = ?
    `);

    stmt.run(status, leadId);

    return res.json({
      success: true,
      message: `Lead ${leadId} updated to status: ${status}`,
    });
  } catch (err) {
    console.error('Error updating lead status:', err);
    return res.status(500).json({
      success: false,
      error: 'Failed to update lead status.',
    });
  }
});

export default router;
